import http from 'http';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const PORT=Number(process.env.PORT||3000), ROOT=__dirname, CATALOG=path.join(ROOT,'catalog.json'), ORDERS=path.join(ROOT,'orders.json'), UP=path.join(ROOT,'uploads');
const ADMIN_USERNAME=process.env.ADMIN_USERNAME||'Z', ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'change-this', SECRET=process.env.SESSION_SECRET||'dev-secret';
const json=async f=>{try{return JSON.parse(await fs.readFile(f,'utf8'))}catch{return []}};
const write=async(f,d)=>fs.writeFile(f,JSON.stringify(d,null,2));
const body=async req=>{let s='';for await(const c of req)s+=c;return s?JSON.parse(s):{}};
const send=(res,status,data,type='application/json')=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store'});res.end(type.includes('json')?JSON.stringify(data):data)};
const cookie=req=>{const c=req.headers.cookie||'';const m=c.match(/zv40=([^;]+)/);if(!m)return false;const [u,s]=Buffer.from(m[1],'base64url').toString().split('.');return !!u&&crypto.timingSafeEqual(Buffer.from(s||''),Buffer.from(crypto.createHmac('sha256',SECRET).update(u).digest('base64url')))};
const session=(res)=>{const u='admin';const s=crypto.createHmac('sha256',SECRET).update(u).digest('base64url');res.setHeader('Set-Cookie',`zv40=${Buffer.from(u+'.'+s).toString('base64url')}; HttpOnly; SameSite=Lax; Path=/`)};
async function app(req,res){
 const u=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,{ok:true,version:'40',paymentMode:process.env.PAYMENT_MODE||'test',provider:process.env.PAYMENT_PROVIDER||'paytr'});
 if(req.method==='GET'&&u.pathname==='/api/catalog')return send(res,200,await json(CATALOG));
 if(req.method==='POST'&&u.pathname==='/api/admin/login'){let b=await body(req);if(b.username===ADMIN_USERNAME&&b.password===ADMIN_PASSWORD){session(res);return send(res,200,{ok:true})}return send(res,401,{ok:false,error:'Yönetici bilgileri hatalı.'})}
 if(req.method==='POST'&&u.pathname==='/api/admin/logout'){res.setHeader('Set-Cookie','zv40=; Max-Age=0; Path=/');return send(res,200,{ok:true})}
 if(u.pathname.startsWith('/api/admin')&&!cookie(req))return send(res,401,{ok:false,error:'Yetkisiz'});
 if(req.method==='GET'&&u.pathname==='/api/admin/orders')return send(res,200,await json(ORDERS));
 if(req.method==='PUT'&&u.pathname==='/api/admin/catalog'){let b=await body(req);if(!Array.isArray(b))return send(res,400,{error:'Geçersiz katalog'});await write(CATALOG,b);return send(res,200,{ok:true})}
 if(req.method==='POST'&&u.pathname==='/api/checkout'){let b=await body(req), products=await json(CATALOG), cart=Array.isArray(b.items)?b.items:[];if(!cart.length)return send(res,400,{error:'Sepet boş.'});let lines=[],total=0;for(const x of cart){let p=products.find(z=>String(z.id)===String(x.id));let q=Math.max(1,Math.min(99,Number(x.qty)||1));if(!p||p.stock<q)return send(res,409,{error:`${p?.name||'Ürün'} için yeterli stok yok.`});let price=Number(p.price)||0;lines.push({id:p.id,name:p.name,qty:q,price});total+=price*q}let orders=await json(ORDERS), id='ZV-'+String(Date.now()).slice(-8);let order={id,createdAt:new Date().toISOString(),status:'payment_pending',customer:b.customer||{},items:lines,total};orders.unshift(order);await write(ORDERS,orders);if((process.env.PAYMENT_MODE||'test')==='test')return send(res,200,{ok:true,test:true,orderId:id,message:'Test ödeme ekranına geçiliyor.'});return send(res,501,{ok:false,error:'Canlı ödeme sağlayıcısı henüz hesap bilgileriyle yapılandırılmadı.'})}
 if(req.method==='POST'&&u.pathname==='/api/test-payment'){let b=await body(req), orders=await json(ORDERS), o=orders.find(x=>x.id===b.orderId);if(!o)return send(res,404,{error:'Sipariş bulunamadı'});o.status='paid_test';o.paidAt=new Date().toISOString();await write(ORDERS,orders);return send(res,200,{ok:true,orderId:o.id})}
 if(req.method==='GET'&&u.pathname.startsWith('/uploads/')){try{let f=path.join(UP,path.basename(u.pathname));let d=await fs.readFile(f);res.writeHead(200,{'Content-Type':'image/webp'});return res.end(d)}catch{return send(res,404,{error:'not found'})}}
 if(req.method==='GET'){let f=u.pathname==='/'?path.join(ROOT,'index.html'):path.join(ROOT,u.pathname);try{let d=await fs.readFile(f);let ext=path.extname(f);let type=ext==='.html'?'text/html; charset=utf-8':ext==='.css'?'text/css':ext==='.js'?'text/javascript':'application/octet-stream';return send(res,200,d.toString(),type)}catch{return send(res,404,'Not found','text/plain')}}
 send(res,404,{error:'Not found'})
}
await fs.mkdir(UP,{recursive:true});try{await fs.access(ORDERS)}catch{await write(ORDERS,[])}
http.createServer((req,res)=>app(req,res).catch(e=>send(res,500,{error:'Sunucu hatası'}))).listen(PORT,()=>console.log('Zanvielle V40 http://localhost:'+PORT));
