import http from 'http';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const PORT=Number(process.env.PORT||3000), ROOT=__dirname, CATALOG=path.join(ROOT,'catalog.json'), ORDERS=path.join(ROOT,'orders.json'), PAYMENT=path.join(ROOT,'payment.json'), UP=path.join(ROOT,'uploads');
const ADMIN_USERNAME=process.env.ADMIN_USERNAME||'Z', ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'145399', SECRET=process.env.SESSION_SECRET||'dev-secret';
const json=async f=>{try{return JSON.parse(await fs.readFile(f,'utf8'))}catch{return []}};
const write=async(f,d)=>fs.writeFile(f,JSON.stringify(d,null,2));
const rawBody=async req=>{let s='';for await(const c of req)s+=c;return s};
const body=async req=>{let s=await rawBody(req);return s?JSON.parse(s):{}};
const formBody=async req=>{let s=await rawBody(req);return Object.fromEntries(new URLSearchParams(s))};
const send=(res,status,data,type='application/json')=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store'});res.end(type.includes('json')?JSON.stringify(data):data)};
const payConfig=async()=>{let c=await json(PAYMENT);return c&&typeof c==='object'&&!Array.isArray(c)?c:{}};
const hmac=(key,text)=>crypto.createHmac('sha256',key).update(text).digest('base64');
const cookie=req=>{const c=req.headers.cookie||'';const m=c.match(/zv40=([^;]+)/);if(!m)return false;const [u,s]=Buffer.from(m[1],'base64url').toString().split('.');return !!u&&crypto.timingSafeEqual(Buffer.from(s||''),Buffer.from(crypto.createHmac('sha256',SECRET).update(u).digest('base64url')))};
const session=(res)=>{const u='admin';const s=crypto.createHmac('sha256',SECRET).update(u).digest('base64url');res.setHeader('Set-Cookie',`zv40=${Buffer.from(u+'.'+s).toString('base64url')}; HttpOnly; SameSite=Lax; Path=/`)};
async function app(req,res){
 const u=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,{ok:true,version:'40',paymentMode:process.env.PAYMENT_MODE||'test',provider:process.env.PAYMENT_PROVIDER||'paytr'});
 if(req.method==='GET'&&u.pathname==='/api/catalog')return send(res,200,await json(CATALOG));
 if(req.method==='POST'&&u.pathname==='/api/admin/login'){let b=await body(req);if(b.username===ADMIN_USERNAME&&b.password===ADMIN_PASSWORD){session(res);return send(res,200,{ok:true})}return send(res,401,{ok:false,error:'Yönetici bilgileri hatalı.'})}
 if(req.method==='POST'&&u.pathname==='/api/admin/logout'){res.setHeader('Set-Cookie','zv40=; Max-Age=0; Path=/');return send(res,200,{ok:true})}
 if(u.pathname.startsWith('/api/admin')&&!cookie(req))return send(res,401,{ok:false,error:'Yetkisiz'});
 if(req.method==='GET'&&u.pathname==='/api/admin/orders')return send(res,200,await json(ORDERS));
 if(req.method==='GET'&&u.pathname==='/api/admin/payment'){let c=await payConfig();return send(res,200,{configured:!!(c.merchant_id&&c.merchant_key&&c.merchant_salt),merchant_id:c.merchant_id||'',base_url:c.base_url||'',test_mode:c.test_mode!==false})}
 if(req.method==='PUT'&&u.pathname==='/api/admin/payment'){let b=await body(req);if(!b.merchant_id||!b.merchant_key||!b.merchant_salt)return send(res,400,{error:'PayTR merchant_id, merchant_key ve merchant_salt zorunlu.'});let c={merchant_id:String(b.merchant_id).trim(),merchant_key:String(b.merchant_key).trim(),merchant_salt:String(b.merchant_salt).trim(),base_url:String(b.base_url||'').trim().replace(/\/$/,''),test_mode:b.test_mode!==false};await write(PAYMENT,c);return send(res,200,{ok:true})}
 if(req.method==='PUT'&&u.pathname==='/api/admin/catalog'){let b=await body(req);if(!Array.isArray(b))return send(res,400,{error:'Geçersiz katalog'});await write(CATALOG,b);return send(res,200,{ok:true})}
 if(req.method==='POST'&&u.pathname==='/api/checkout'){
  let b=await body(req), products=await json(CATALOG), cart=Array.isArray(b.items)?b.items:[];
  if(!cart.length)return send(res,400,{error:'Sepet boş.'});
  let lines=[],total=0;
  for(const x of cart){let p=products.find(z=>String(z.id)===String(x.id));let q=Math.max(1,Math.min(99,Number(x.qty)||1));if(!p||p.stock<q)return send(res,409,{error:`${p?.name||'Ürün'} için yeterli stok yok.`});let price=Number(p.price)||0;lines.push({id:p.id,name:p.name,qty:q,price});total+=price*q}
  let orders=await json(ORDERS), id='ZV-'+String(Date.now()).slice(-8), customer=b.customer||{};
  let order={id,createdAt:new Date().toISOString(),status:'payment_pending',customer,items:lines,total};orders.unshift(order);await write(ORDERS,orders);
  let cfg=await payConfig();
  if(!cfg.merchant_id||!cfg.merchant_key||!cfg.merchant_salt){
    if((process.env.PAYMENT_MODE||'test')==='test')return send(res,200,{ok:true,test:true,orderId:id});
    return send(res,400,{error:'PayTR henüz yapılandırılmadı. Yönetici > Ödeme Ayarları bölümünden PayTR bilgilerini gir.'});
  }
  let base=cfg.base_url||process.env.PUBLIC_BASE_URL||`http://${req.headers.host}`;
  let userIp=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').toString().split(',')[0].replace(/^::ffff:/,'');
  let basket=Buffer.from(JSON.stringify(lines.map(x=>[x.name,Number(x.price).toFixed(2),x.qty]))).toString('base64');
  let amount=Math.round(total*100), testMode=cfg.test_mode===false?'0':'1', noInstallment='0', maxInstallment='0', currency='TL';
  let hashStr=cfg.merchant_id+userIp+id+(customer.email||'')+amount+basket+noInstallment+maxInstallment+currency+testMode;
  let token=hmac(cfg.merchant_key,hashStr+cfg.merchant_salt);
  let params=new URLSearchParams({merchant_id:cfg.merchant_id,user_ip:userIp,merchant_oid:id,email:customer.email||'noemail@example.com',payment_amount:String(amount),paytr_token:token,user_basket:basket,user_name:customer.name||'',user_address:customer.address||'',user_phone:customer.phone||'',merchant_ok_url:base+'/odeme-basarili?order='+encodeURIComponent(id),merchant_fail_url:base+'/odeme-hata?order='+encodeURIComponent(id),timeout_limit:'30',debug_on:'1',test_mode:testMode,no_installment:noInstallment,max_installment:maxInstallment,currency,lang:'tr'});
  try{let pr=await fetch('https://www.paytr.com/odeme/api/get-token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params});let pd=await pr.json();if(pd.status!=='success'){order.status='payment_error';order.paymentError=pd.reason||'PayTR token alınamadı';await write(ORDERS,orders);return send(res,502,{error:'PayTR ödeme ekranı hazırlanamadı: '+(pd.reason||'Bilinmeyen hata')})}order.paytrTokenCreatedAt=new Date().toISOString();await write(ORDERS,orders);return send(res,200,{ok:true,provider:'paytr',token:pd.token,orderId:id})}catch(e){order.status='payment_error';order.paymentError='PayTR bağlantı hatası';await write(ORDERS,orders);return send(res,502,{error:'PayTR sunucusuna bağlanılamadı.'})}
 }
 if(req.method==='POST'&&u.pathname==='/api/paytr/callback'){
  let p=await formBody(req), cfg=await payConfig();
  if(!cfg.merchant_key||!cfg.merchant_salt)return send(res,500,'CONFIG ERROR','text/plain');
  let expected=hmac(cfg.merchant_key,String(p.merchant_oid||'')+cfg.merchant_salt+String(p.status||'')+String(p.total_amount||''));
  if(!p.hash||!crypto.timingSafeEqual(Buffer.from(p.hash),Buffer.from(expected)))return send(res,400,'PAYTR notification failed: bad hash','text/plain');
  let orders=await json(ORDERS), o=orders.find(x=>x.id===p.merchant_oid);if(!o)return send(res,200,'OK','text/plain');
  if(o.status==='paid'||o.status==='payment_failed')return send(res,200,'OK','text/plain');
  if(p.status==='success'){o.status='paid';o.paidAt=new Date().toISOString();o.payment={provider:'paytr',paymentType:p.payment_type||'card',totalAmount:Number(p.total_amount||0)/100,currency:p.currency||'TL'}}else{o.status='payment_failed';o.paymentError=p.failed_reason_msg||'Ödeme başarısız';}
  await write(ORDERS,orders);return send(res,200,'OK','text/plain')
 }
 if(req.method==='POST'&&u.pathname==='/api/test-payment'){let b=await body(req), orders=await json(ORDERS), o=orders.find(x=>x.id===b.orderId);if(!o)return send(res,404,{error:'Sipariş bulunamadı'});o.status='paid_test';o.paidAt=new Date().toISOString();await write(ORDERS,orders);return send(res,200,{ok:true,orderId:o.id})}
 if(req.method==='GET'&&u.pathname.startsWith('/uploads/')){try{let f=path.join(UP,path.basename(u.pathname));let d=await fs.readFile(f);res.writeHead(200,{'Content-Type':'image/webp'});return res.end(d)}catch{return send(res,404,{error:'not found'})}}
 if(req.method==='GET'){let f=u.pathname==='/'?path.join(ROOT,'index.html'):path.join(ROOT,u.pathname);try{let d=await fs.readFile(f);let ext=path.extname(f);let type=ext==='.html'?'text/html; charset=utf-8':ext==='.css'?'text/css':ext==='.js'?'text/javascript':'application/octet-stream';return send(res,200,d.toString(),type)}catch{return send(res,404,'Not found','text/plain')}}
 send(res,404,{error:'Not found'})
}
await fs.mkdir(UP,{recursive:true});try{await fs.access(ORDERS)}catch{await write(ORDERS,[])}try{await fs.access(PAYMENT)}catch{await write(PAYMENT,{test_mode:true})}
http.createServer((req,res)=>app(req,res).catch(e=>send(res,500,{error:'Sunucu hatası'}))).listen(PORT,()=>console.log('Zanvielle V40 http://localhost:'+PORT));
